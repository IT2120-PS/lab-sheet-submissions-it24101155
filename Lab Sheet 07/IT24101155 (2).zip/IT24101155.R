setwd("C:/Users/ASUS/OneDrive/Desktop/IT24101155")
p_train <- punif(25, min = 0, max = 40, lower.tail = TRUE) -
  punif(10, min = 0, max = 40, lower.tail = TRUE)
cat("Q1. Probability train between 8:10 and 8:25 =", p_train, "\n")
p_update <- pexp(2, rate = 1/3, lower.tail = TRUE)
cat("Q2. Probability update ≤ 2 hours =", p_update, "\n")
mu <- 100
sigma <- 15
p_iq_above_130 <- pnorm(130, mean = mu, sd = sigma, lower.tail = FALSE)
cat("Q3(i). Probability IQ > 130 =", p_iq_above_130, "\n")
iq_95th <- qnorm(0.95, mean = mu, sd = sigma)
cat("Q3(ii). 95th Percentile IQ =", iq_95th, "\n")
