dbinom(40,44,0.92)
pbinom(35,44,0.92,lower.tail=TRUE)
1-pbinom(37,44,0.92,lower.tail = TRUE)
pbinom(37,44,0.92,lower.tail = FALSE)
pbinom(42,44,0.92,lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail = TRUE)
dpois(6,5)
ppois(6,5,lower.tail = FALSE)
setwd("C:\\Users\\it24101155\\Downloads\\IT24101155")
n<-50
p<-0.85
pbinom(46,50,0.85)
# i. Random variable X = number of calls received in an hour
lamda<-12
ppois(15,12)
